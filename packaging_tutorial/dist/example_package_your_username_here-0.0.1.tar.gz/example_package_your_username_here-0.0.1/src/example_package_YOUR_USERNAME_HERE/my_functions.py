
# File containing a function
import numpy as np
def greet(name):
    return f"Hello, {name}!"

def add_one(number):
    arr = np.arange(10)
    return number + 1